import streamlit as st
import pickle
model = pickle.load(open('model.pkl', 'rb'))

def predict_crop(n, p, k, temperature, humidity, ph, rainfall):
    input = np.array([[n, p, k, temperature, humidity, ph, rainfall]]).astype(np.float64)
    prediction = model.predict(input)
    return prediction

def main():
    st.title("Crop Prediction")
    html_temp = """
    <div style="background-color:#025246 ;padding:10px">
    <h2 style="color:white;text-align:center;"> Which Crop To Cultivate? </h2>
    </div>
    """
    st.markdown(html_temp, unsafe_allow_html=True)

    n = st.text_input("Nitrogeb","Type Here")
    p = st.text_input("Phosphorus","Type Here")
    k = st.text_input("Potassium","Type Here")
    ph = st.text_input("ph","Type Here")
    temperature = st.text_input("Temperature","Type Here")
    humidity = st.text_input("Humidity","Type Here")
    rainfall = st.text_input("Rainfall","Type Here")

    safe_html="""  
      <div style="background-color:#F4D03F;padding:10px >
       <h2 style="color:white;text-align:center;"> Your forest is safe</h2>
       </div>
    """

    if st.button("Predict"):
        output=predict_crop(n, p, k, temperature, humidity, ph, rainfall)
        st.success('The most suitable crop for your field is {}'.format(output))
        st.markdown(safe_html,unsafe_allow_html=True)

if __name__=='__main__':
    main()
    