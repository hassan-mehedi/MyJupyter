import numpy as numpy
import pandas as pd 

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier

import warnings
import pickle

warnings.filterwarnings("ignore")

df = pd.read_csv("crop_prediction_model_one.csv")
df = np.array(df)

X = df[1:, 1:-1]
y = df[1:, -1 ]
X = X.astype("int")
y = y.astype("int")

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)

rfc = RandomForestClassifier(n_estimators=200)
rfc.fit(X_train, y_train)
pickle.dump(rfc, open('model.pkl', 'wb'))